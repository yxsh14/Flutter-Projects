import 'package:flutter/material.dart';
import 'package:login_signup/components/common/splash.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My App',
      theme: ThemeData(
        colorScheme: const ColorScheme.light(
          primary: Color(0xFF233743), // Set your default primary color here
          secondary: Colors.green,
        ),
        // Set your default accent color here (e.g., used for buttons)
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(
              0xFF233743), // Set your default color for the title bar (AppBar) here
        ),
        // Add more theme customization here if needed
      ),
      home: const Splash(),
    );
  }
}

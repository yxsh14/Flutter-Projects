// ignore_for_file: avoid_unnecessary_containers

import 'package:flutter/material.dart';

import '../login_page.dart';

class Splash extends StatefulWidget {
  const Splash({super.key});

  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  bool animate = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    startAnimation();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          AnimatedPositioned(
            duration: const Duration(milliseconds: 1600),
            top: animate ? 10 : -30,
            left: 120,
            child: const Image(
              width: 250,
              image: AssetImage("assets/images/splesh1.png"),
            ),
          ),
          // AnimatedPositioned(
          //   duration: const Duration(milliseconds: 1600),
          //   top: animate ? 0 : -60,
          //   right: animate ? 0 : -60,
          //   child: const Image(
          //     width: 120,
          //     image: AssetImage("assets/images/splesh3.png"),
          //   ),
          // ),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 1600),
            top: 300,
            left: animate ? 120 : -80,
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 1600),
              opacity: animate ? 1 : 0,
              child: Text(
                "FundYourFuture",
                style: Theme.of(context).textTheme.headlineMedium,
              ),
            ),
          ),
          // AnimatedPositioned(
          //   duration: const Duration(milliseconds: 1600),
          //   top: 180,
          //   left: animate ? 0 : -30,
          //   child: const Image(
          //     width: 180,
          //     image: AssetImage("assets/images/splesh4.png"),
          //   ),
          // ),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 2400),
            bottom: animate ? 110 : 0,
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 1600),
              opacity: animate ? 1 : 0,
              child: const Image(
                width: 500,
                image: AssetImage("assets/images/splesh2.png"),
              ),
            ),
          ),
          AnimatedPositioned(
            duration: const Duration(milliseconds: 1600),
            right: animate ? 120 : -80,
            bottom: 105,
            child: AnimatedOpacity(
              duration: const Duration(milliseconds: 1600),
              opacity: animate ? 1 : 0,
              child: Text(
                "Find Scholarships with Ease.",
                style: Theme.of(context).textTheme.headlineSmall,
              ),
            ),
          ),
          // AnimatedPositioned(
          //   duration: const Duration(milliseconds: 1600),
          //   bottom: animate ? 0 : -30,
          //   right: 20,
          //   child: const Image(
          //     width: 100,
          //     image: AssetImage("assets/images/splesh5.png"),
          //   ),
          // ),
        ],
      ),
    );
  }

  Future startAnimation() async {
    await Future.delayed(const Duration(microseconds: 500));
    setState(() => animate = true);
    await Future.delayed(const Duration(milliseconds: 5000));
    Navigator.pushReplacement(
        context, MaterialPageRoute(builder: (context) => LoginPage()));
  }
}
